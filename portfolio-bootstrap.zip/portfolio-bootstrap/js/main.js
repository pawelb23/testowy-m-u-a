'use strict';

console.log('Portfolio - Bootstrap');